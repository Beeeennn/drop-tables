import pandas as pd
import openpyxl
import matplotlib.pyplot as plt

#origional opening of file
df_T = pd.read_excel('Superstore Dataset.xlsx',usecols = "C,R,T")
count = 0
hold = 0.0
prev = 0.0
par = []
up = []
##Average on sale / not on sale

Sale = df_T[df_T['Discount'] == 0]
Disc = df_T[df_T['Discount'] != 0]

print(Sale.mean(),Disc.mean())


# load excel with its path 
wrkbk = openpyxl.load_workbook("Superstore Dataset.xlsx") 

sh = wrkbk.active 


# start of the plot to compare past current and previous sales
fig, ax = plt.subplots(figsize=(10, 6))
ax.scatter(x = up, y =par)


# iterate through excel and display data 
for i in range(2, sh.max_row+1):
    cell_obj = sh.cell(row=i, column=20)

    if cell_obj.value != 0.0:
        count+=1
        if count == 30:
            count == 0
        try:
            hold += float(cell_obj.value)
        except:
            pass
        

    
    if cell_obj.value == 0.0:
        count+=1
        if count == 30:
            count == 0
        try:
            hold += float(cell_obj.value)
        except:
            pass

    par.append(hold)
    up.append(count)
    hold = 0.0



#diaplaying graph
ax.scatter(x = up, y =par)
plt.show()
